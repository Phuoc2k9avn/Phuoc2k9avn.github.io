var extpay = ExtPay('khanv12');

// Check payment status immediately when content script runs
chrome.storage.local.get(['paid'], function(result) {
    if (result.paid) {
        injectScriptFile();
    } else {
        console.log("Tool Chưa Được Kích Hoạt Tính Năng Sẽ Không Hoạt Động.");
    }
});

// Listen for messages from popup.js or other parts of the extension
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "checkPaidStatus") {
        chrome.storage.local.get(['paid'], function(result) {
            if (result.paid) {
                injectScriptFile();
            } else {
                console.log("Tool Chưa Được Kích Hoạt Tính Năng Sẽ Không Hoạt Động.");
            }
        });
    } else if (request.action === "removeInjectedScripts") {
        removeScriptFile();
    }
});

function injectScriptFile() {
    if (!document.getElementById('khanv12')) {
        const scriptElement = document.createElement('script');
        scriptElement.src = chrome.runtime.getURL('inject.js');
        (document.head || document.documentElement).appendChild(scriptElement);
    }
}

function removeScriptFile() {
    const scriptElement = document.getElementById('khanv12');
    if (scriptElement) {
        scriptElement.remove();
        console.log("Injected script has been removed.");
    }
}