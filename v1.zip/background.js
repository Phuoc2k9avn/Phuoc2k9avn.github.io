importScripts('ExtPay.js');

var extpay = ExtPay('khanv12');
extpay.startBackground();

// Initial check
checkUserStatus();

// Set up an interval to check the payment status every 1 second
setInterval(checkUserStatus, 100); // 1000 ms = 1 second

// Function to check and handle user payment status
function checkUserStatus() {
    extpay.getUser().then(user => {
        chrome.storage.local.get(['paid'], function(result) {
            const wasPaid = result.paid;
            const isPaid = user.paid;

            // Store the current payment status
            chrome.storage.local.set({ paid: isPaid });

            // If the user just paid or just canceled their subscription, refresh the Khan Academy page
            if (isPaid && !wasPaid) {
                console.log('Bạn Vừa Mua Tool Hãy Tải Lại Trang KhanAcademy');
                refreshKhanAcademyPage();
                injectScript();
            } else if (!isPaid && wasPaid) {
                console.log('Bạn Vừa Từ Chối Mua Tool...');
                refreshKhanAcademyPage();
                removeInjectedScripts();
            }
        });
    }).catch(err => {
        console.error("Lỗi Thông Tin", err);
    });
}

// Function to refresh all Khan Academy tabs
function refreshKhanAcademyPage() {
    chrome.tabs.query({ url: "*://*.khanacademy.org/*" }, function(tabs) {
        tabs.forEach(function(tab) {
            chrome.tabs.reload(tab.id);
        });
    });
}

// Function to inject the script into Khan Academy page
function injectScript() {
    chrome.tabs.query({ url: "*://*.khanacademy.org/*" }, function(tabs) {
        tabs.forEach(function(tab) {
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['contentScript.js']
            });
        });
    });
}

// Function to remove injected scripts from Khan Academy page
function removeInjectedScripts() {
    chrome.tabs.query({ url: "*://*.khanacademy.org/*" }, function(tabs) {
        tabs.forEach(function(tab) {
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['removeContentScript.js'] // Ensure this script exists and undoes the injection
            });
        });
    });
}